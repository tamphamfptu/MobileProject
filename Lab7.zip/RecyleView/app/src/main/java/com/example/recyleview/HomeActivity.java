package com.example.recyleview;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
        TextView userName = findViewById(R.id.userName);
        Button productBtn = findViewById(R.id.productList);
        Button closeBtn = findViewById(R.id.closeBtn);
        Button dropdownBtn = findViewById(R.id.showDropdown);

        Intent intent = getIntent();
        String username = getIntent().getStringExtra("keyusername");


        //set new name base on input
        userName.setText(username);

        //get input username
        Toast.makeText(HomeActivity.this, "Welcum " + username, Toast.LENGTH_SHORT).show();

        productBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, ShowActivity.class);
                startActivity(intent);
            }
        });

        dropdownBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, Dropdown.class);
                startActivity(intent);
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(99, intent);
                finish();
            }
        });
    }
}
